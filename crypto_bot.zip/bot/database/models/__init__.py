from bot.database.models.main import *
from .main import register_models
