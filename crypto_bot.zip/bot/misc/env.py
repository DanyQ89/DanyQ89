import os
from abc import ABC
from typing import Final


class EnvKeys(ABC):
    TOKEN: Final = '6666095340:AAH2XQk29_7G8op5a0erCNIyzcULtLS8hEM'
    OWNER: Final = '935351006'
    CLIENT_TOKEN: Final = 'AgAAAAA2zr9wAAaV0UJ0eOq4r9W0f5aDcQ'
    RECEIVER_TOKEN: Final = 'AgAAAAA2zr9wAAaV0UJ0eOq4r9W0f5aDcQ'
    DB_USERNAME: Final = 'postgres'
    DB_PASSWORD: Final = '1234'
    DB_HOST: Final = 'localhost'
    DB_NAME: Final = 'cryptomus'
