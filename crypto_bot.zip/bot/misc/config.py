from abc import ABC
from typing import Final


class TgConfig(ABC):
    STATE: Final = {}
