from aiogram import Dispatcher


def register_all_filters(dp: Dispatcher):
    pass
